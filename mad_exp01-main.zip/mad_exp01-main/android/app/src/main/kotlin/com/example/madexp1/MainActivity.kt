package com.example.madexp1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
